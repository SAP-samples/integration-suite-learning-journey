var clientreceivedstarttime = context.getVariable('client.received.start.timestamp');
var clientreceivedendtime =context.getVariable('client.received.end.timestamp');
context.setVariable("proxy_request_receiving_latency",clientreceivedendtime-clientreceivedstarttime);

