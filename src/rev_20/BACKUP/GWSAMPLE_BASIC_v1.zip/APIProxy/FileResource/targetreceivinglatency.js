var targetsentstarttime = context.getVariable('target.sent.start.timestamp');
var targetsentendtime =context.getVariable('target.sent.end.timestamp');
context.setVariable("target_receiving_request_latency",targetsentendtime-targetsentstarttime);

var targetreceivedstarttime = context.getVariable('target.received.start.timestamp');
var targetreceivedendtime =context.getVariable('target.received.end.timestamp');
context.setVariable("proxy__receiving_response_latency",targetreceivedendtime-targetreceivedstarttime);